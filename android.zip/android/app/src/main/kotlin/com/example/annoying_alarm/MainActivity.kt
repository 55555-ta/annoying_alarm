package com.example.annoying_alarm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
